SKIPMOUNT=false
PROPFILE=false
POSTFSDATA=false
LATESTARTSERVICE=true

REPLACE="
"

# Checking if busybox is installed, Credit to the person who made it.
GetBusyBox="none"
alias DSC="["
alias DDC="[["
sleep 1s
for i in /system/bin /system/xbin /sbin /su/xbin /data/adb/modules/busybox-ndk/system/xbin /data/adb/modules_update/busybox-ndk/system/xbin /data/adb/modules/busybox-ndk/system/bin /data/adb/modules_update/busybox-ndk/system/bin
do
    if [[ "$GetBusyBox" == "none" ]]; then
        if [[ -f $i/busybox ]]; then
            GetBusyBox=$i/busybox
        fi
    fi
done

if [[ "$GetBusyBox" == "none" ]];then
    GetBusyBox=""
    abort "ERROR: Please Flash Busybox First!"
else
    for ListCmds in $($GetBusyBox --list)
    do
        if [[ "$ListCmds" == "[" ]];then
            alias "DSC"="$GetBusyBox $ListCmds"
        elif [[ "$ListCmds" == "[[" ]];then
            alias "DDC"="$GetBusyBox $ListCmds"
        else
            alias "$ListCmds"="$GetBusyBox $ListCmds"
        fi
    done
fi

# Permission For install.sh
chmod 755 $MODPATH/install.sh

z="
";jCz='='\''na';nBz='='\''t,';OCz='='\''we';vDz='Zz$e';YCz='ern'\''';RDz='z$Bz';MEz='$qz$';tBz='z='\'';';sBz='╝'\'';T';aDz='Lz$M';iz='ai'\'';';LDz='e'\'';O';CBz='oz='\''';sDz='$Wz$';IBz=''\'';wz';xCz=';Oz=';PDz='eval';ZBz=''\'';CB';dCz='r -'\''';ez='Sz='\''';ZCz=';kz=';dBz=''\''el ';CCz='e'\'';y';eDz='z$Rz';EEz='$z$V';OBz=''\'';dz';NEz='Zz$r';qCz='e'\'';W';bCz='I'\'';j';hz='='\''@K';pz=''\''OR=';lBz='ep '\''';uDz='$Yz$';jz='QBz=';eEz='Bz$J';pBz='uz='\''';GDz='ID="';VBz=';Lz=';Fz='slee';aBz='z='\''o';OEz='sz$d';BEz='$jz$';xz='🇮�'\''';WDz='z$Hz';Nz='hor ';PBz='='\''"'\''';YBz='exit';QDz=' "$A';pDz='z$cz';Cz='='\''el';iCz=';EBz';yDz='gz$h';nEz='Bz$d';cCz='z='\''e';SEz='$z$v';cEz='Bz$H';vz='e'\'';F';VDz='$Gz$';NDz=''\'';ez';uCz=''\''ent';XBz='g'\'';S';RBz='='\''a.';BBz='d.'\'';';nz='═══'\''';bDz='z$Nz';EDz='ta'\'';';hCz='mod'\''';KBz='DBz=';Oz=''\'';JB';jEz='Bz$O';MDz='llat';vBz=';Uz=';wCz='Sta'\''';iEz='Bz$N';rCz='z='\''p';yBz=''\''e"'\''';Iz='on '\''';oBz=' I'\'';';pEz='TBz$';DDz='='\''ns';sCz=' 0.'\''';gz=''\'';Cz';yz=';RBz';Jz=';rz=';SBz='k.'\'';';Bz='";vz';kDz='z$Zz';ACz=';Ez=';VEz='yz$A';NBz='nami';jDz='$z$Y';JBz='Mo'\'';';wDz='z$fz';HBz='='\''fi';XEz='Bz$C';YEz='Bz$D';ZEz='Bz$E';dDz='Pz$Q';QBz=';FBz';bEz='Bz$G';Wz=';GBz';LBz=''\''rig';az='ZHY ';QCz='Gz='\''';MBz='i'\'';K';aEz='Bz$F';JCz=';fz=';KDz=''\''Hib';XCz='z='\''K';LEz='z$pz';gBz='sil'\''';LCz=' '\'';B';TEz='z$wz';lz='r'\'';b';AEz='z$iz';Lz='═'\'';A';cBz=';hz=';HDz=''\'';LB';WBz=''\''if ';UCz=';Dz=';UEz='$xz$';SDz='$Cz$';nCz=';HBz';kz=''\''abo';lCz='tz='\''';TCz=''\'' 1'\''';Gz=''\'';PB';qDz='$dz$';aCz=''\'' NO';lDz='$az$';hDz='Vz$W';UDz='z$Fz';pCz='\'\'''\''v';qz='"'\'';R';CDz=';NBz';FEz='z$Wz';Uz='z='\''H';fz='prop';IEz='$Zz$';nDz='z$bz';iDz='z$Xz';BCz=''\''urc';TDz='Dz$E';qEz='z$UB';Mz='Bz='\''';TBz='Xz='\''';wz='z='\'' ';tDz='Xz$z';gDz='Tz$U';WCz='o'\'';g';ZDz='z$z$';fDz='$Sz$';FDz='Hz='\''';Tz='t'\'';P';oEz='SBz$';mCz=' ""'\''';cz='='\'' "';EBz=''\'';IB';tCz=';qz=';UBz='008'\''';JDz=';Iz=';CEz='kz$l';gEz='Bz$L';mz='z='\''═';dz='╔═'\'';';Hz='z='\''i';NCz=''\'';iz';fBz='"'\'';p';ADz='T'\'';Z';qBz='p 2'\''';wBz=''\''en'\''';tz=';xz=';vCz='"'\'';n';REz='z$uz';eBz='T'\'';m';oCz='='\''u'\''';sz='le.'\''';kBz='z='\''r';eCz=';Yz=';yCz=''\''$AU';QEz='z$tz';HCz='z='\''A';SCz='TBz=';hEz='Bz$M';KEz='nz$o';FBz='bee'\''';IDz='g i'\''';XDz='$Iz$';FCz=''\''-q ';mDz='bz$b';fEz='Bz$K';Az='z="';xBz=';Kz=';DBz='y in';RCz='�"'\'';';GBz=';UBz';Sz=''\''rna';VCz=''\''zeS';ICz='UTH'\''';Zz='lz='\''';Ez='Vz='\''';xDz='$fz$';Kz=''\'' "╚';MCz='is n';BDz='int'\''';rDz='z$Vz';Pz='z='\''n';oz=';Bz=';HEz='z$Yz';mBz=';MBz';gCz='p'\'';Q';cDz='$Oz$';DCz='aut'\''';kEz='Bz$P';Dz='se'\'';';Xz='='\''a ';dEz='Bz$I';YDz='Jz$K';Qz=' re'\''';iBz=''\''═══';ODz='  '\'';';fCz=''\''ui_';GEz='$Xz$';rz='z='\''u';rBz=';sz=';uBz=' th'\''';oDz='$bz$';Rz=';Jz=';Yz='yo'\'';';lEz='Bz$Q';Vz='OR"'\''';KCz=''\''   ';bBz='t O'\''';bz=''\'';az';uz=''\''dul';ECz=';Nz=';jBz='╗'\'';M';DEz='z$mz';WEz='Bz$B';JEz='ez$f';PCz='ak'\'';';GCz='"'\'';A';mEz='Bz$R';PEz='Yz$Z';rEz='z"';ABz='='\''te';kCz='l '\'';';hBz=';cz=';
eval "$Az$z$Bz$Cz$Dz$Ez$Fz$Gz$Hz$Iz$Jz$Kz$Lz$Mz$Nz$Oz$Pz$Qz$Rz$Sz$Tz$Uz$Vz$Wz$Xz$Yz$Zz$az$bz$cz$dz$ez$fz$gz$hz$iz$jz$kz$lz$mz$nz$oz$pz$qz$rz$sz$tz$uz$vz$wz$xz$yz$ABz$BBz$CBz$DBz$EBz$wz$FBz$GBz$HBz$IBz$cz$JBz$KBz$LBz$MBz$Mz$NBz$OBz$PBz$QBz$RBz$SBz$TBz$UBz$VBz$WBz$XBz$Mz$YBz$ZBz$aBz$bBz$cBz$dBz$eBz$wz$fBz$wz$gBz$hBz$iBz$jBz$kBz$lBz$mBz$nBz$oBz$pBz$qBz$rBz$iBz$sBz$tBz$uBz$vBz$wBz$xBz$yBz$ACz$BCz$CCz$wz$DCz$ECz$FCz$GCz$HCz$ICz$JCz$KCz$LCz$Mz$MCz$NCz$OCz$PCz$QCz$RCz$SCz$TCz$UCz$VCz$WCz$XCz$YCz$ZCz$aCz$bCz$cCz$dCz$eCz$fCz$gCz$wz$hCz$iCz$jCz$kCz$lCz$mCz$nCz$oCz$pCz$qCz$rCz$sCz$tCz$uCz$vCz$wz$wCz$xCz$yCz$ADz$kBz$BDz$CDz$DDz$EDz$FDz$GDz$HDz$Pz$IDz$JDz$KDz$LDz$Mz$MDz$NDz$cz$ODz$z$PDz$QDz$RDz$SDz$TDz$UDz$VDz$WDz$XDz$YDz$ZDz$aDz$bDz$cDz$dDz$eDz$fDz$gDz$ZDz$hDz$iDz$jDz$kDz$lDz$mDz$nDz$oDz$mDz$pDz$qDz$rDz$sDz$tDz$uDz$vDz$wDz$xDz$yDz$AEz$BEz$CEz$DEz$EEz$FEz$GEz$HEz$IEz$JEz$wDz$xDz$KEz$LEz$MEz$rDz$sDz$tDz$uDz$NEz$nDz$oDz$mDz$nDz$oDz$OEz$ZDz$PEz$QEz$EEz$REz$SEz$ZDz$PEz$TEz$UEz$VEz$WEz$XEz$YEz$ZEz$aEz$bEz$cEz$dEz$eEz$fEz$gEz$hEz$iEz$jEz$kEz$lEz$mEz$nEz$ZDz$oEz$pEz$qEz$rEz"

ui_print ""
    ui_print ""
    ui_print "                      Device Info"
    ui_print "         ====================================="
    sleep 3
    ui_print ""
    ui_print ""
    sleep 0.008
    ui_print "          >    Android version: $(getprop ro.build.version.release)"
    sleep 0.008
    ui_print "          >    Brand: $(getprop ro.product.system.manufacturer)"
    sleep 0.008
    ui_print "          >    Build number: $(getprop ro.build.display.id)"
    sleep 0.008
    ui_print "          >    CPU: $(getprop ro.hardware)"
    sleep 0.008
    ui_print "          >    Code Name: FFH4X"
    sleep 0.008
    ui_print "          >    Device: $(getprop ro.product.model)"
    sleep 0.008
    ui_print "          >    Kernel: $(uname -r)"
    sleep 0.008
    ui_print "          >    Locale: $(getprop ro.product.locale)"
    sleep 0.008
    ui_print "          >    Model: $(getprop ro.build.product)"
    sleep 0.008
    ui_print "          >    Nation/region: $(getprop ro.build.oplus_nv_id)"
    sleep 0.008
    ui_print "          >    Processor: $(getprop ro.product.board)"
    sleep 0.008
    ui_print "          >    RAM: $(free | grep Mem | awk '{print $2}')"
    sleep 0.008
    ui_print "          >    Baseline: $(getprop ro.build.version.incremental)"
    sleep 0.008
    
    # Set Permission files
    ui_print ""
    ui_print ""
    sleep 3
    ui_print ""
    ui_print ""
    ui_print "                     Flashing module"
    ui_print "         ====================================="
    sleep 3
    rm -rf /data/media/0/Android/Noizhy-KT/KT.log
    mkdir /data/media/0/Android/Noizhy-KT/KT.log
    set_permissions
    set_perm_recursive $MODPATH 0 0 0777 0777

    # Final message
    ui_print ""
    ui_print ""
    sleep 3
    ui_print "                        done."
    sleep 3
    su -c "nohup am start -a android.intent.action.VIEW -d https://t.me/KaizeSource >/dev/null 2>&1 &"