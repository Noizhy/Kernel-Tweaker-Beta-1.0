#!/system/bin/sh

# # #  S e r v i c e  .  s h # # #
# Created By @Noizhy a.k.a Kaize Team
# Published on Telegram at 16 - 2 - 2024

rm -rf /data/media/0/Android/KaizeModules
mkdir /data/media/0/Android/KaizeModules

check_file() {
  if [[ -f "$1" ]]; then
    return 0
  else
    return 1
  fi
}

read_file_unlock() {
  if check_file "$1"; then
    chmod 444 "$1"
    cat "$1"
    chmod 644 "$1"  
  fi
}

write_file_lock() {
  if check_file "$1"; then
    chmod 644 "$1"  
    echo "$2" > "$1"
    chmod 444 "$1"
  fi
}

twk() {
    local msg="$1"
    local log_path="/data/media/0/Android/KaizeModules/Hibernate-Kaize.log"
    echo "Kernel Tweaker - Success | $msg" >> "$log_path"
    echo "" >> "$log_path"
}

error() {
    local msg="$1"
    local log_path="/data/media/0/Android/KaizeModules/Hibernate-Kaize.log"
    echo "Kernel Tweaker - Error | $msg" >> "$log_path"
    echo "" >> "$log_path"
}

# This Script is made by @Noizhy

# Optimize CPU Governor for Performance
if echo "performance" > /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor; then
    twk "CPU Governor set to performance for CPU0 successfully."
else
    error "Failed to set CPU Governor for CPU0."
fi

if echo "performance" > /sys/devices/system/cpu/cpu4/cpufreq/scaling_governor; then
    twk "CPU Governor set to performance for CPU4 successfully."
else
    error "Failed to set CPU Governor for CPU4."
fi

if echo "performance" > /sys/devices/system/cpu/cpu7/cpufreq/scaling_governor; then
    twk "CPU Governor set to performance for CPU7 successfully."
else
    error "Failed to set CPU Governor for CPU7."
fi

# Set IO Scheduler for Speed
for i in /sys/block/*/queue/scheduler; do
    if echo "deadline" > $i; then
        twk "IO Scheduler set to deadline for $i successfully."
    else
        error "Failed to set IO Scheduler for $i."
    fi
done

# Tune Virtual Memory Parameters
if echo "1" > /proc/sys/vm/dirty_background_ratio &&
   echo "20" > /proc/sys/vm/dirty_ratio &&
   echo "vm.dirty_writeback_centisecs = 1500" >> /etc/sysctl.conf; then
    twk "Virtual Memory parameters tuned successfully."
else
    error "Failed to tune Virtual Memory parameters."
fi

# Enable TCP Congestion Control Setting
if echo "net.ipv4.tcp_congestion_control = bbr" >> /etc/sysctl.conf; then
    twk "TCP Congestion Control set to BBR successfully."
else
    error "Failed to set TCP Congestion Control to BBR."
fi

# Set GPU Performance Governor
if echo "performance" > /sys/class/kgsl/kgsl-3d0/devfreq/governor; then
    twk "GPU Performance Governor set to performance successfully."
else
    error "Failed to set GPU Performance Governor."
fi

# Optimize File System Caching
if echo "4096" > /proc/sys/vm/min_free_kbytes &&
   echo "1500" > /proc/sys/vm/dirty_writeback_centisecs; then
    twk "File System Caching optimized successfully."
else
    error "Failed to optimize File System Caching."
fi

# Stabilize CPU Frequency Under High Workloads
if echo "85" > /sys/devices/system/cpu/cpufreq/interactive/go_hispeed_load &&
   echo "30000" > /sys/devices/system/cpu/cpufreq/interactive/above_hispeed_delay; then
    twk "CPU Frequency stabilized successfully."
else
    error "Failed to stabilize CPU Frequency."
fi

# Optimize Network Throughput
if echo "net.core.rmem_max = 16777216" >> /etc/sysctl.conf &&
   echo "net.core.wmem_max = 16777216" >> /etc/sysctl.conf &&
   echo "net.ipv4.tcp_rmem = 4096 87380 16777216" >> /etc/sysctl.conf &&
   echo "net.ipv4.tcp_wmem = 4096 16384 16777216" >> /etc/sysctl.conf; then
    twk "Network Throughput optimized successfully."
else
    error "Failed to optimize Network Throughput."
fi

# Manage Wi-Fi Signal Stability
if echo "wifi.supplicant_scan_interval = 180" >> /etc/wifi/wpa_supplicant.conf; then
    twk "Wi-Fi Signal Stability managed successfully."
else
    error "Failed to manage Wi-Fi Signal Stability."
fi

# Optimize Touch Screen Response Speed
if echo "500" > /sys/class/input/input0/report_rate_hz; then
    twk "Touch Screen Response Speed optimized successfully."
else
    error "Failed to optimize Touch Screen Response Speed."
fi

# Adjust System Animation Speed
if echo "0.5" > /sys/class/graphics/fb0/msm_fb_panic/framerate; then
    twk "System Animation Speed adjusted successfully."
else
    error "Failed to adjust System Animation Speed."
fi

# Tune DPI Scale for Screen Resolution
if echo "240" > /sys/class/graphics/fb0/devicexdpi &&
   echo "240" > /sys/class/graphics/fb0/deviceydpi; then
    twk "DPI Scale tuned successfully."
else
    error "Failed to tune DPI Scale."
fi

# Improve IRQ Management for CPU Core
if echo "1" > /proc/irq/default_smp_affinity; then
    twk "IRQ Management for CPU Core improved successfully."
else
    error "Failed to improve IRQ Management for CPU Core."
fi

# Configure Aggressive Garbage Collection
if echo "gc_every=100" > /etc/dalvikvm-heap.conf &&
   echo "gc_delay=100" >> /etc/dalvikvm-heap.conf; then
    twk "Aggressive Garbage Collection configured successfully."
else
    error "Failed to configure Aggressive Garbage Collection."
fi

# Optimize Task Scheduler for Multicore
if echo "1" > /proc/sys/kernel/sched_migration_cost_ns; then
    twk "Task Scheduler optimized for Multicore successfully."
else
    error "Failed to optimize Task Scheduler for Multicore."
fi

# Increase Priority for Game Processes
if echo "-20" > /proc/sys/kernel/sched_child_runs_first; then
    twk "Priority for Game Processes increased successfully."
else
    error "Failed to increase Priority for Game Processes."
fi

# Boost Read/Write Speed of Internal Storage (IO Speed)
if echo "deadline" > /sys/block/mmcblk0/queue/scheduler; then
    twk "IO Speed boosted successfully."
else
    error "Failed to boost IO Speed."
fi

# Configure Low-Latency Audio Performance
if echo "256" > /proc/sys/fs/inotify/max_user_instances; then
    twk "Low-Latency Audio Performance configured successfully."
else
    error "Failed to configure Low-Latency Audio Performance."
fi

# Optimize Low Latency for Input Device
if echo "1" > /sys/class/input/input0/bounce_keys; then
    twk "Low Latency optimized for Input Device successfully."
else
    error "Failed to optimize Low Latency for Input Device."
fi

# Adjust TCP/IP Stack Performance
if echo "net.ipv4.tcp_low_latency = 1" >> /etc/sysctl.conf &&
   echo "net.ipv4.tcp_window_scaling = 1" >> /etc/sysctl.conf; then
    twk "TCP/IP Stack Performance adjusted successfully."
else
    error "Failed to adjust TCP/IP Stack Performance."
fi

echo "Kernel tuning completed."